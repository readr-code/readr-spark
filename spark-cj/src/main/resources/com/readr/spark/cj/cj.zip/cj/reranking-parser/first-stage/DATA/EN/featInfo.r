18

  1   rt		0  0 |
  2   rtR1		1  1 |
  3   rtR1R2		2  2 |
  4   rtR1R2Qr		3  3 |
  5   rtR1R2QrR3	4  4 |
  6   rtR1R2QrR3c	5  5 |
  7   rtR1R2QrR3cu	6  6 |
  8   rtR1R2QrR3cuv	7  7 |
  9   rtR1R2QrR3cuh	8  7 |

--

  0    t   0  1 |
  1    R1  15 2 |	
  2    R2  16 3 |
  3    Qr   17 4 |
  4    R3  20 5 |
  5    c   12 6 |
  6    u   2  7 |
  7    v   6  8 |
  8    h   3  9 | 

--

--

FactorPos= 5
